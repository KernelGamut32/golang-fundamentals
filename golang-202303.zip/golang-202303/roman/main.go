package main

import (
	"fmt"
	"strings"
)

var translations = map[rune]int{
	'M': 1000,
	'D': 500,
	'C': 100,
	'L': 50,
	'X': 10,
	'V': 5,
	'I': 1,
}

func main() {
	// var number string
	// fmt.Print("Enter a Roman Number: ")
	// fmt.Scanln(&number)

	number := "MCMLDIX"
	fmt.Printf("%s is equivalent to %d\n", number, translate(strings.ToUpper(number)))
}

func translate(number string) int { // MCM
	arabicVals := make([]int, len(number) + 1)
	for index, digit := range number { // index = 0-based position of the character, digit = character
		if value, present := translations[digit]; present { // protects against invalid like MZM
			arabicVals[index] = value
		} else {
			fmt.Printf("bad digit: %c\n", digit)
		}
	}
	fmt.Println("Before:", arabicVals)
	total := 0
	for c := 0; c < len(number); c++ {
		if arabicVals[c] < arabicVals[c+1] {
			arabicVals[c] = -arabicVals[c]
		}
		total += arabicVals[c]
	}
	fmt.Println("After:", arabicVals)
	return total
}
