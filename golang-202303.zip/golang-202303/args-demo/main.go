package main

import (
	"fmt"
	"os"
)

func main() {
	fmt.Println("All command-line args:", os.Args)
	fmt.Println("Number of args =", len(os.Args))
	fmt.Println("Arg 0 is", os.Args[0])
	fmt.Println("Args 1-3 are", os.Args[1:4])
	fmt.Println(os.Args[1] + os.Args[2] + os.Args[3])
}
