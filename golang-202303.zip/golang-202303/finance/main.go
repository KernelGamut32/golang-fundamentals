package main

import (
	"fmt"

	"github.com/KernelGamut32/golang-202303/packages/banking"
)

func main() {
	bankAccount1, err := banking.OpenNewAccount("Melissa", "Testing", 200.00)
	if err != nil {
		fmt.Println("Error opening bank account", err)
		return
	}

	bankAccount2, err := banking.OpenNewAccount("Bob", "Roberts", 150.00)
	if err != nil {
		fmt.Println("Error opening bank acccount", err)
		return
	}

	if res, err := bankAccount1.Deposit(10); err != nil {
		fmt.Println(err)
	} else {
		fmt.Printf("%s: Balance after deposit is %.2f\n", bankAccount1.GetName(), res)
	}

	if _, err := bankAccount2.Withdraw(50); err != nil {
		fmt.Println(err)
	} else {
		fmt.Printf("%s: Balance after withdrawal is %.2f\n", bankAccount2.GetName(), bankAccount2.CheckBalance())
	}

	jointAccount := bankAccount1.CreateJointAccount(bankAccount2)
	fmt.Printf("%s: %.2f\n", jointAccount.GetName(), jointAccount.CheckBalance())
}
