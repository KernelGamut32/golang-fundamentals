package main

import (
	"fmt"
	"math"
)

func main() {
	a, c := circleinfo(4.2)
	fmt.Printf("Area = %.2f, Circumference = %.2f\n", a, c)
}

func circleinfo(r float64) (float64, float64) {
	return math.Pi * r * r, math.Pi * r * 2
}
