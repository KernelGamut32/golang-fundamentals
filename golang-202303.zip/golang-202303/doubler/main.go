package main

import "fmt"

func main() {
	str := "Golang"
	// doublerAlt(str)
	doubler(&str)
	fmt.Println(str)
}

// func doublerAlt(s string) {
// 	s += s
// 	//fmt.Println(s)
// }

func doubler(s *string) {
	doubleHelper(s)
}

func doubleHelper(s *string) {
	*s += *s
}