package main

import (
	"fmt"
)

func pinger(c chan string) {
	fmt.Println("pinger about to send")
	c <- "ping...ping...ping" // send a value into a channel ... blocking operation
}

func main() {
	mychan := make(chan string) // Create a new channel
	go pinger(mychan)           // run pinger() as a goroutine
	// fmt.Println("goroutine started...waiting 3 seconds before receiving")
	// time.Sleep(3 * time.Second)
	msg := <-mychan // receive value from channel ... this is a blocking operation
	fmt.Println(msg)
}
