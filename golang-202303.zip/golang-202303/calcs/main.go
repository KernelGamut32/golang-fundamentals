package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

var ops = map[rune]func(int, int) int{
	'+': add,
	'-': sub,
	'*': mult,
	'/': div,
	'^': weird,
}

func main() {
	scanner := bufio.NewScanner(os.Stdin)
	var op rune
	var num1, num2 int

	for scanner.Scan() {
		line := scanner.Text()
		if line == "quit" {
			return
		}
		line = strings.Replace(line, " ", "", -1)
		if n, err := fmt.Sscanf(line, "%d%c%d", &num1, &op, &num2); err == nil && n == 3 {
			// 2 + 3 --> 2+3 --> num1 = 2, op = +, num2 = 3, 2+3+5
			if f, present := ops[op]; present {
				fmt.Println(f(num1, num2))
			} else {
				fmt.Printf("bad operator: %c\n", op)
			}
		} else {
			fmt.Println("bad line:", line)
		}
	}
}

func add(x, y int) int {
	return x + y
}

func sub(x, y int) int {
	return x - y
}

func mult(x, y int) int {
	return x * y
}

func div(x, y int) int {
	return x / y
}

func weird(x, y int) int {
	return x + y - 2*x + y + 1000
}
