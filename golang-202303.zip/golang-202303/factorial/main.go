package main

import "fmt"

func main() {
	var num int

	fmt.Print("Enter a number: ")
	fmt.Scanln(&num)
	fmt.Println(factorial(num))
}

func factorial(num int) int { // num = 5
	if num == 0 {
		return 1
	}

	result := num // result = 5

	for i := num - 1; i > 1; i-- { //result = 120, i = 1
		// result = result * i
		result *= i // result = 60 * 2 = 120
	}

	return result
}
