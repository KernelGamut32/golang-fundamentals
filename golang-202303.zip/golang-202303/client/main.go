package main

import (
	"fmt"

	"github.com/KernelGamut32/golang-202303/packages/formatter"
	"github.com/KernelGamut32/golang-202303/packages/utilities"
)

func main() {
	num := utilities.Add(3, 4)
	num2 := utilities.Scale(8)
	fmt.Println(formatter.Format(num))
	fmt.Println(formatter.Format(num2))
	// fmt.Println(internal.Prefix)
}
