package utilities

func Add(op1, op2 int) int {
	return op1 + op2
}
