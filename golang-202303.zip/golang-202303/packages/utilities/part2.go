package utilities

const factor = 4

func Scale(op1 int) int {
	return op1 * factor
}
