package banking

import "errors"

var bankConfig struct {
	minOpeningBalance float64
}

func init() {
	bankConfig.minOpeningBalance = 25.0
}

type BankAccount struct {
	Customer
	balance float64
}

func OpenNewAccount(first string, last string, startingBalance float64) (*BankAccount, error) {
	if startingBalance < bankConfig.minOpeningBalance {
		return nil, errors.New("banking: invalid opening balance")
	}
	bankAccount := &BankAccount{balance: startingBalance}
	bankAccount.ChangeName(first, last)
	return bankAccount, nil
}

func (b *BankAccount) Deposit(amount float64) (float64, error) {
	if amount <= 0 {
		return b.balance, errors.New("banking: invalid deposit amount")
	}
	b.balance += amount
	return b.balance, nil
}

func (b *BankAccount) Withdraw(amount float64) (float64, error) {
	if amount <= 0 {
		return b.balance, errors.New("banking: invalid withdrawal amount")
	} else if amount > b.balance {
		return b.balance, errors.New("banking: overdrawn account")
	}
	b.balance -= amount
	return b.balance, nil
}

func (b *BankAccount) CheckBalance() float64 {
	return b.balance
}

func (b *BankAccount) CreateJointAccount(other *BankAccount) *BankAccount {
	result := &BankAccount{
		balance: b.balance + other.balance,
	}
	result.ChangeName(b.Customer.firstName + " | " + other.firstName, b.Customer.lastName + " | " + other.lastName)
	return result
}
