package main

import (
	"fmt"
	"os"
	"strconv"
)

func main() {
	var num1 int
	var err error

	// num1, err = strconv.Atoi(os.Args[1])
	// if err != nil {
	if num1, err = strconv.Atoi(os.Args[1]); err != nil {
		fmt.Println("Error:", err)
	}
	num2, _ := strconv.Atoi(os.Args[2])
	fmt.Println(num1 + num2)
}
