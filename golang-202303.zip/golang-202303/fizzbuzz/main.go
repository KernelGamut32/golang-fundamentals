package main

import (
	"fmt"
	"strconv"
)

func main() {
	tests := [...]int{3, 4, 5, 15}
	for index, num := range tests {
		fmt.Printf("%d. %d results in %s\n", index + 1, num, fizzbuzz(num))
	}
}

func fizzbuzz(num int) string {
	switch {
	case num%15 == 0:
		return "fizzbuzz"
	case num%3 == 0:
		return "fizz"
	case num%5 == 0:
		return "buzz"
	default:
		return strconv.Itoa(num)
	}
}