package main

import "fmt"

func main() {
	s := make([]string, 25)
	s[0] = "raspberry"
	s[1] = "orange"
	s[2] = "guava"
	s[3] = "grape"
	s[4] = "mango"
	// s := []string{"raspberry", "orange", "guava", "grape", "mango"}
	fmt.Printf("%v %d %d\n", s, len(s), cap(s))
	t := s[1:3]
	fmt.Printf("%v %d %d\n", t, len(t), cap(t))
	t[0] = "fruit-t"
	fmt.Printf("%s %s\n", s[1], t[0])
	u := s[1:3:3]
	fmt.Printf("%v %d %d\n", u, len(u), cap(u))
	v := s[1:3:5]
	fmt.Printf("%v %d %d\n", v, len(v), cap(v))
	// e1 := s[1:3:2]
	// fmt.Printf("%v %d %d\n", e1, len(e1), cap(e1))
	e2 := s[1:3:18]
	fmt.Printf("%v %d %d\n", e2, len(e2), cap(e2))
}
