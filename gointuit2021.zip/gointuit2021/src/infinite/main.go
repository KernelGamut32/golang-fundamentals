package main

import (
	"fmt"
	"os"
	"strconv"
)

var version string

func main() {
	if os.Args[1] == "version" {
		fmt.Println("Version:", version)
		return
	}
	fmt.Printf("You entered %d\n", getInt())
}

func getInt() int {
	var str string

	for {
		fmt.Print("Enter an integer: ")
		fmt.Scanln(&str)
		if res, err := strconv.Atoi(str); err != nil {
			fmt.Println("...not an integer, try again!")
		} else {
			return res
		}
	}
}
