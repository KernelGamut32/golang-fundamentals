package main

import "fmt"

func main() {
	tests := [][]int{
		{1, 2, 3},
		{4, 5},
		{},
	}
	for _, test := range tests {
		fmt.Println(test, "->", product(test...))
	}
	fmt.Println(product(1, 8, -3, 14))
}

func product(nums ...int) int {
	p := 1

	if len(nums) == 0 {
		return p
	}

	for _, num := range nums {
		p *= num
	}

	return p
}
