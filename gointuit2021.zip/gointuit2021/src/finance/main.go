package main

import (
	"fmt"

	"github.com/KernelGamut32/go/src/packages/banking"
)

func main() {
	// bankAccount1, err := banking.OpenNewAccount("Melissa Testing", 10.0)
	bankAccount1, err := banking.OpenNewAccount("Melissa", "Testing", 200.0)
	if err != nil {
		fmt.Println("Error opening bank account", err)
		return
	}

	bankAccount2, err := banking.OpenNewAccount("Bob", "Roberts", 175.0)
	if err != nil {
		fmt.Println("Error opening bank account", err)
		return
	}

	if res, err := bankAccount1.Deposit(10); err == nil {
		fmt.Printf("Balance after deposit is %.2f\n", res)
	} else {
		fmt.Println(err)
	}
	// if res, err := bankAccount1.Withdraw(500); err == nil {
	if res, err := bankAccount1.Withdraw(50); err == nil {
		fmt.Printf("Balance after withdrawal is %.2f\n", res)
	} else {
		fmt.Println(err)
	}

	jointAccount := bankAccount1.CreateJointAccount(bankAccount2)
	fmt.Printf("Balance of joint account is %.2f\n", jointAccount.CheckBalance())
	fmt.Println(jointAccount.GetName())
}
