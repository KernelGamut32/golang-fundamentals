package main

import "fmt"

type IPAddr [4]byte

func (i IPAddr) String() string {
	return fmt.Sprintf("%d.%d.%d.%d", i[0], i[1], i[2], i[3])
}

var addresses = map[string]IPAddr{
	"localhost.com":  {127, 0, 0, 1},
	"www.google.com": {10, 10, 254, 3},
	"www.intuit.com": {1, 2, 3, 4},
}

func main() {
	fmt.Println(addresses["localhost.com"])
	fmt.Println(addresses["www.google.com"])
	fmt.Println(addresses["www.intuit.com"])
}
