package main

import (
	"fmt"
	"math/rand"
	"sync"
	"time"
)

var wg sync.WaitGroup

func main() {
	rand.Seed(time.Now().Unix())
	for i := 1; i <= 100000; i++ {
		wg.Add(1)
		go waiter(i)
	}
	wg.Wait()
}

func waiter(num int) {
	defer wg.Done()
	seconds := rand.Int31n(5) + 1
	fmt.Printf("Waiter %d is waiting for %d seconds\n", num, seconds)
	time.Sleep(time.Duration(seconds) * time.Second)
	fmt.Printf("Waiter %d done\n", num)
}
