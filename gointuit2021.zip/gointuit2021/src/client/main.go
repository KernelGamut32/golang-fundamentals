package main

import (
	"fmt"

	"github.com/KernelGamut32/go/src/packages/formatter"
	"github.com/KernelGamut32/go/src/packages/utility"
)

func main() {
	num := utility.Add(3, 4)
	num2 := utility.Scale(8)
	fmt.Println(formatter.Format(num))
	fmt.Println(formatter.Format(num2))
}
