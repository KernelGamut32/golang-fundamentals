package banking

import "errors"

var bankConfig struct {
	minOpeningBalance float64
}

func init() {
	bankConfig.minOpeningBalance = 25.0
}

type BankAccount struct {
	Customer
	balance float64
}

func OpenNewAccount(first string, last string, start float64) (*BankAccount, error) {
	if start < bankConfig.minOpeningBalance {
		return nil, errors.New("banking: invalid opening balance")
	}
	bankAcount := &BankAccount{balance: start}
	bankAcount.ChangeName(first, last)
	return bankAcount, nil
}

func (b *BankAccount) Deposit(amount float64) (float64, error) {
	if amount <= 0 {
		return b.balance, errors.New("banking: invalid deposit amount")
	}
	b.balance += amount
	return b.balance, nil
}

func (b *BankAccount) Withdraw(amount float64) (float64, error) {
	if amount <= 0 {
		return b.balance, errors.New("banking: invalid withdrawal amount")
	} else if amount > b.balance {
		return b.balance, errors.New("banking: that would make you overdrawn")
	}
	b.balance -= amount
	return b.balance, nil
}

func (b *BankAccount) CheckBalance() float64 {
	return b.balance
}

func (b *BankAccount) CreateJointAccount(other *BankAccount) *BankAccount {
	result := &BankAccount{
		Customer{b.Customer.firstName + " | " + other.firstName, b.lastName + " | " + other.lastName},
		b.balance + other.balance,
	}
	// result.ChangeName(b.firstName+" | "+other.firstName, b.lastName+" | "+other.lastName)
	return result
}
