package formatter

import (
	"fmt"

	"github.com/KernelGamut32/go/src/packages/internal"
)

func Format(num int) string {
	return fmt.Sprintf("%s: The numbers is %d\n", internal.Prefix, num)
}
