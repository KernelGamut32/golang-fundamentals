package internal

const Prefix = "I did something"
