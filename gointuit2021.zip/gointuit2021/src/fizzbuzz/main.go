package main

import (
	"fmt"
	"strconv"
)

func main() {
	testNums := [...]int{3, 4, 5, 15}
	for _, num := range testNums {
		fmt.Printf("%s\n", fizzbuzz2(num))
	}
}

// func fizzbuzz(num int) string {
// 	switch {
// 	case num%15 == 0:
// 		return "fizzbuzz"
// 	case num%3 == 0:
// 		return "fizz"
// 	case num%5 == 0:
// 		return "buzz"
// 	default:
// 		return strconv.Itoa(num)
// 	}
// }

func fizzbuzz2(num int) string {
	var fizz, buzz string

	if num%3 == 0 {
		fizz = "fizz"
	}
	if num%5 == 0 {
		buzz = "buzz"
	}
	if fizz+buzz == "" {
		return strconv.Itoa(num)
	}
	return fizz + buzz
}
