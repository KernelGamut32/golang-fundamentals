package main

import "fmt"

func main() {
	str := "Golang"
	doubler(&str)
	fmt.Println(str)
}

func doubler(s *string) {
	doublerHelper(s)
}

func doublerHelper(s *string) {
	*s += *s
}
