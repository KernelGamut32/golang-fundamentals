package main

import (
	"fmt"
	"strconv"
	"time"
)

func main() {
	var work string
	workchans := [2]chan int{
		make(chan int),
		make(chan int),
	}

	go server(workchans[0], 1)
	go server(workchans[1], 2)

	for {
		fmt.Print("Work? ")
		if n, _ := fmt.Scanln(&work); n == 0 {
			continue
		}
		if work == "quit" {
			fmt.Println("Stopping")
			break
		}
		if secs, err := strconv.Atoi(work); err == nil {
			select {
			case workchans[0] <- secs:
				fmt.Println("Work sent to server 1")
			case workchans[1] <- secs:
				fmt.Println("Work sent to server 2")
			}
		}
	}
}

func server(c chan int, num int) {
	for {
		work := <-c
		fmt.Printf("Database server %d working for %d seconds...\n", num, work)
		time.Sleep(time.Duration(work) * time.Second)
		fmt.Printf("Database server %d done\n", num)
	}
}
