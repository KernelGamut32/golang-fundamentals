package main

import (
	"fmt"
	"math/rand"
	"time"
)

func main() {
	val := 1
	rand.Seed(time.Now().Unix())

	defer func() {
		if r := recover(); r == "error - negative number entered" {
			fmt.Println("recovering from panic")
			fmt.Println("cleanup here!")
		} else if r != nil {
			panic(r)
		}
	}()

	for {
		fmt.Print("Enter an integer: ")
		fmt.Scanf("%d", &val)

		if val == 0 {
			break
		}

		if val < 0 {
			panic("error - negative number entered")
		}

		if rand.Float64() <= 0.1 {
			panic("random")
		}
	}

	fmt.Println("exiting")
}
