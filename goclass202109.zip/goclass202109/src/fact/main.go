package main

import "fmt"

func main() {
	var num int

	fmt.Print("Enter a number: ")
	fmt.Scanln(&num)
	fmt.Println(fact(num))
}

func fact(num int) int {
	if num == 0 {
		return 1
	}

	result := num

	for i := num - 1; i > 1; i-- {
		result *= i
	}

	return result
}
