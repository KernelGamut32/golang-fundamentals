package main

import (
	"fmt"
	"strings"
)

func main() {
	fmt.Println(counter("Everyone", "Hello", "Blah", "Encyclopedia", "Encyclopediae"))
}

func counter(words ...string) []string {
	if len(words) == 0 {
		return words
	}
	result := make([]string, 0)
	for i := 0; i < len(words); i++ {
		if strings.Count(strings.ToLower(words[i]), "e") >= 3 {
			result = append(result, words[i])
		}
	}
	return result
}