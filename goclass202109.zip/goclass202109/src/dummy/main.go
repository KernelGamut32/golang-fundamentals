package main

import "fmt"

func main() {
	a := []string{"one", "two", "four", "five"}
	ss1 := make([]string, 2)
	ss2 := make([]string, 2)
	copy(ss1, a[:2])
	copy(ss2, a[2:])
	s := ss1
	s = append(s, "three")
	s = append(s, ss2...)
	fmt.Println(s)
}
