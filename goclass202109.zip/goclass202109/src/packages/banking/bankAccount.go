package banking

import (
	"errors"
)

var bankConfig struct {
	minOpeningBalance float64
}

func init() {
	bankConfig.minOpeningBalance = 25.0
}

type BankAccount struct {
	Customer
	balance float64
}

func OpenNewAccount(first string, last string, start float64) (*BankAccount, error) {
	if start < bankConfig.minOpeningBalance {
		return nil, errors.New("banking: invalid opening balance")
	}
	bankAccount := &BankAccount{
		balance: start,
	}
	bankAccount.ChangeName(first, last)
	return bankAccount, nil
}

func (b *BankAccount) Deposit(amount float64) (float64, error) {
	if amount <= 0 {
		return b.balance, errors.New("banking: invalid deposit amount")
	}
	b.balance += amount
	return b.balance, nil
}

func (b *BankAccount) Withdraw(amount float64) (float64, error) {
	if amount <= 0 {
		return b.balance, errors.New("banking: invalid withdrawal amount")
	} else if amount > b.balance {
		return b.balance, errors.New("banking: account overdraw")
	}
	b.balance -= amount
	return b.balance, nil
}

func (b *BankAccount) CheckBalance() float64 {
	return b.balance
}

func (b *BankAccount) CreateJointAccount(other *BankAccount) *BankAccount {
	result := &BankAccount{
		Customer{
			firstName: b.firstName + "|" + other.firstName,
			lastName:  b.lastName + "|" + other.lastName,
		},
		b.balance + other.balance,
	}
	return result
}
