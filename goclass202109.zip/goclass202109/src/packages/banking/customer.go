package banking

import "fmt"

type Customer struct {
	firstName string
	lastName  string
}

func (c *Customer) ChangeName(first string, last string) {
	c.firstName = first
	c.lastName = last
}

func (c *Customer) GetFullName() string {
	return fmt.Sprintf("%s, %s\n", c.lastName, c.firstName)
}
