package utility

const factor = 4

func Add(op1, op2 int) int {
	return op1 + op2
}

func Scale(op1 int) int {
	return op1 * factor
}
