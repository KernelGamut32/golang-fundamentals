package main

import (
	"fmt"

	"github.com/KernelGamut32/golab/src/packages/formatter"
	"github.com/KernelGamut32/golab/src/packages/internal"
	"github.com/KernelGamut32/golab/src/packages/utility"
)

func main() {
	fmt.Println(internal.Prefix)
	num1 := utility.Add(3, 4)
	num2 := utility.Scale(8)
	fmt.Println(formatter.Format(num1))
	fmt.Println(formatter.Format(num2))
}
